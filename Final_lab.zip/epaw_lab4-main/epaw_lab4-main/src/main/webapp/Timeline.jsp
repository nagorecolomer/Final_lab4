<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<div class="w3-container w3-card w3-round w3-margin-bottom" 
     style="background-color: var(--bg-surface) !important; border: 1px solid var(--border-color) !important; padding: 20px; color: var(--text-primary) !important;">
    
    <h5 style="color: var(--accent-green); font-family: monospace; font-weight: bold; margin-top: 0; margin-bottom: 12px;">
        [+] BROADCAST NEW LOG ENTRY
    </h5>

    <div class="w3-row-padding" style="padding:0;">
        <div class="w3-col m2 w3-center w3-hide-small">
            <img src="${user.picture}" class="w3-circle" style="width:55px; height:55px; object-fit: cover; border: 2px solid var(--border-color);" alt="User Avatar">
        </div>
        
        <div class="w3-col m10">
            <p style="color: var(--text-secondary); font-family: monospace; font-size: 0.8em; margin: 0 0 5px 0;">
                >_ input_content:
            </p>
            
            <div id="tweetContent" contenteditable="true" class="w3-input w3-border" 
                 style="background-color: #0b0f19 !important; border: 1px solid var(--border-color) !important; color: #38bdf8 !important; min-height: 70px; font-family: monospace; padding: 10px; border-radius: 4px; overflow-y: auto;"
                 placeholder="Escribe un mensaje de seguridad..."></div>
            
            <div class="w3-margin-top w3-right-align">
                <button type="button" id="addTweet" class="w3-button w3-round" 
                        style="background-color: var(--accent-green); color: #000; font-weight: bold; font-family: monospace; padding: 6px 15px;">
                    <i class="fa fa-pencil"></i> PUBLISH_LOG
                </button>
            </div>
        </div>
    </div>
</div>

<div id="iterator"></div>

<script type="text/javascript">
$(document).ready(function(){
    // IMPORTANTE: En lugar de cargar 'Tweets' a secas, cargamos la lista 
    // pasándole un parámetro para que el backend sepa que queremos el Timeline global.
    $('#iterator').load('Tweets');
});
</script>
