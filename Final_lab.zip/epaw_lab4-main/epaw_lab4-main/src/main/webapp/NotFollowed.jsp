<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<c:choose>
    <c:when test="${empty users}">
        <div class="w3-container w3-center" style="padding: 20px; color: var(--text-secondary);">
            <p style="font-family: monospace;">[SYSTEM] No suggestions available.</p>
        </div>
    </c:when>
    <c:otherwise>
        <h5 style="color: var(--text-secondary); font-family: monospace; margin-left: 10px;">[!] Target Suggestions</h5>
        <c:forEach var="u" items="${users}">       
            <div id="${u.id}" class="w3-container w3-card w3-round w3-center w3-section" 
                 style="background-color: var(--bg-surface); border: 1px solid var(--border-color); padding: 10px;">
                <p style="color: var(--accent-green);">${u.name}</p>
                <button type="button" class="followUser w3-button w3-block w3-green w3-small">Follow</button> 
            </div>
        </c:forEach>
    </c:otherwise>
</c:choose>