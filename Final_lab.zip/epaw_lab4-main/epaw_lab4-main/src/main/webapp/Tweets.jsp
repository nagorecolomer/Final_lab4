<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<c:forEach var="t" items="${tweets}">      
 <div id="${t.id}" class="w3-container w3-card w3-section w3-round w3-animate-opacity"
      style="background-color: var(--bg-surface) !important; border: 1px solid var(--border-color) !important; padding: 15px; color: var(--text-primary) !important;"><br>
   
   <i class="fa fa-user-secret w3-left w3-circle w3-margin-right w3-xlarge" style="color: var(--accent-green); margin-top: 5px;"></i>
   
   <span class="w3-right" style="color: var(--text-secondary); font-size: 0.85em; font-family: monospace;"> [${t.postDateTime}] </span>
   
   <h4 style="color: var(--accent-green); font-weight: bold; margin: 0;"> @${t.uname} </h4><br>
   
   <hr style="border-top: 1px solid var(--border-color); margin: 5px 0 12px 0;">
   
   <p style="white-space: pre-wrap; font-size: 1.05em;"> ${t.content} </p>
   
   <button type="button" class="likeTweet w3-button w3-xs w3-round"
           style="background-color: #1e293b; color: #38bdf8; border: 1px solid #334155; margin-right: 5px;">
       <i class="fa fa-thumbs-up"></i> &nbsp;Like
   </button>
   
   <c:if test="${t.uid == user.id}">
       <button type="button" id="${t.id}" class="delTweet w3-button w3-xs w3-round w3-right"
               style="background-color: #271c1c; color: #f87171; border: 1px solid #451a1a;">
           <i class="fa fa-trash"></i> &nbsp;Delete
       </button> 
   </c:if>
 </div>
</c:forEach>

<c:if test="${empty tweets}">
    <div class="w3-container w3-center" style="padding: 30px; color: var(--text-secondary);">
        <i class="fa fa-terminal w3-large" style="color: var(--border-color); margin-bottom: 10px;"></i>
        <p style="font-family: monospace; font-size: 0.9em;">[SYSTEM] No logs recorded for this user ID.</p>
    </div>
</c:if>