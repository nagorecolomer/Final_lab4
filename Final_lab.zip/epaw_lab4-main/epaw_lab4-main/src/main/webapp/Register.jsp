<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" session="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<div class="w3-container w3-card w3-round" 
     style="background-color: var(--bg-surface) !important; border: 1px solid var(--border-color) !important; max-width: 500px; margin: 30px auto; padding: 25px; color: var(--text-primary) !important;">
    
    <h3 style="color: var(--accent-green); font-family: monospace; font-weight: bold; margin-top: 0; text-align: center;">
        [+] REGISTER NEW AGENT
    </h3>
    <p style="color: var(--text-secondary); font-family: monospace; font-size: 0.85em; text-align: center; margin-bottom: 20px;">
        Initialize credentials in the secure database.
    </p>

    <form id="registerForm" action="Register" method="POST" enctype="multipart/form-data">

        <div class="w3-margin-bottom">
            <label for="name" style="color: var(--text-secondary); font-family: monospace; font-size: 0.9em; display: block; margin-bottom: 5px;">
                >_ Username
            </label>
            <input class="w3-input w3-border" type="text" id="name" name="name" required minlength="5" maxlength="20"
                value="${user.name}" title="Username must be between 5 and 20 characters." 
                style="background-color: #0b0f19 !important; border: 1px solid var(--border-color) !important; color: #38bdf8 !important; font-family: monospace; border-radius: 4px;" />
            <span class="w3-text-red" style="font-family: monospace; font-size: 0.8em;">${errors.name}</span>
        </div>

        <div class="w3-margin-bottom">
            <label for="password" style="color: var(--text-secondary); font-family: monospace; font-size: 0.9em; display: block; margin-bottom: 5px;">
                >_ Password
            </label>
            <input class="w3-input w3-border" type="password" id="password" name="password" required
                pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$" value="${user.password}"
                title="Minimum 8 characters, including uppercase, numbers, and a special character (@#$%^&*)." 
                style="background-color: #0b0f19 !important; border: 1px solid var(--border-color) !important; color: #38bdf8 !important; font-family: monospace; border-radius: 4px;" />
            <span class="w3-text-red" style="font-family: monospace; font-size: 0.8em;">${errors.password}</span>
        </div>

        <div class="w3-margin-bottom">
            <label for="confirmPassword" style="color: var(--text-secondary); font-family: monospace; font-size: 0.9em; display: block; margin-bottom: 5px;">
                >_ Repeat Password
            </label>
            <input class="w3-input w3-border" type="password" id="confirmPassword" name="confirmPassword" required 
                value="${user.password}" title="Passwords must match" 
                style="background-color: #0b0f19 !important; border: 1px solid var(--border-color) !important; color: #38bdf8 !important; font-family: monospace; border-radius: 4px;" />
        </div>

        <div class="w3-margin-bottom">
            <label for="picture" style="color: var(--text-secondary); font-family: monospace; font-size: 0.9em; display: block; margin-bottom: 5px;">
                >_ Profile Picture (Avatar)
            </label>
            <input class="w3-input w3-border" type="file" id="picture" name="picture" accept="image/*" 
                style="background-color: #0b0f19 !important; border: 1px solid var(--border-color) !important; color: var(--text-secondary) !important; font-family: monospace; border-radius: 4px; padding: 6px;" />
        </div>

        <button type="submit" class="w3-button w3-block w3-round" 
                style="background-color: var(--accent-green); color: #000; font-weight: bold; font-family: monospace; margin-top: 20px;">
            <i class="fa fa-user-plus"></i> AUTHORIZE_REGISTRATION
        </button>

    </form>
</div>