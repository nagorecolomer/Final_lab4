<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" session="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core"%>

<div class="w3-container w3-card w3-round w3-margin" style="max-width: 500px; margin: auto !important; padding: 25px; background-color: var(--bg-surface) !important; border: 1px solid var(--border-color);">
    <h2 class="w3-center tech-data" style="margin-bottom: 20px;"><i class="fa fa-shield"></i> CyberSec Login</h2>

    <form id="loginForm" action="Login" method="POST" autocomplete="off">

        <div class="w3-section">
            <label for="name" class="w3-text-grey"><b>Username (Alias):</b></label> 
            <input type="text" class="w3-input w3-border w3-round" 
                style="background-color: var(--bg-primary) !important; color: var(--text-primary) !important; border-color: var(--border-color) !important;"
                id="name" name="name" required minlength="5" maxlength="20" value="${user.name}"
                title="Username must be between 5 and 20 characters." />
        </div>
        
        <div class="w3-section">
            <label for="password" class="w3-text-grey"><b>Password:</b></label> 
            <input type="password" class="w3-input w3-border w3-round" 
                style="background-color: var(--bg-primary) !important; color: var(--text-primary) !important; border-color: var(--border-color) !important;"
                id="password" name="password" required
                pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$"
                value="${user.password}"
                title="Minimum 8 characters, including uppercase, numbers, and a special character (@#$%^&*)." />
        </div>

        <button type="submit" class="w3-button w3-block w3-round w3-section main-btn" 
                style="background-color: var(--accent-green) !important; color: #000000 !important; font-weight: bold;">
            <i class="fa fa-sign-in"></i> Log in
        </button>

    </form>
</div>

<script>
    // Creamos el objeto vacío de errores
    App.Errors = {};

    // Inyectamos los errores de manera que el editor lo vea como strings válidos sin marcas rojas
    <c:forEach var="error" items="${errors}">
        App.Errors["${error.key}"] = "${error.value}";
    </c:forEach>

    // Inicializa el validador pasándole los errores del backend
    App.initLoginValidation(App.Errors);    
</script>